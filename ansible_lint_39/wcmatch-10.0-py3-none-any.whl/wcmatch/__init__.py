"""
Wild Card Match.

A custom implementation of `fnmatch` and `glob`.
"""
from .__meta__ import __version_info__, __version__  # noqa: F401
