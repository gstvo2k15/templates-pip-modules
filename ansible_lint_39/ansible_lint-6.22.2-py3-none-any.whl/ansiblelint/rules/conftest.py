"""Makes pytest fixtures available."""
# pylint: disable=wildcard-import,unused-wildcard-import
from ansiblelint.testing.fixtures import *  # noqa: F403
